from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    ld = LaunchDescription()

    feedback_node = Node(
        package="hb_task2a",         
        executable="feedback",      
    )
    service_node = Node(
        package="hb_task2a",           
        executable="service_node",      
    )
    controller_node = Node(
        package="hb_task2a",         
        executable="controller",      
    )

    ld.add_action(feedback_node)
    ld.add_action(service_node)
    ld.add_action(controller_node)
    return ld