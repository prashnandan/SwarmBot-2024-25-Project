#! /usr/bin/env python3

################### IMPORT MODULES #######################
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from geometry_msgs.msg import Pose2D
from std_msgs.msg import String
import cv2
from cv_bridge import CvBridge
import numpy as np
import math

##############################################################
class ArUcoDetector(Node):

    def __init__(self):
        super().__init__('aruco_detector')

        # Subscribe the topic /camera/image_raw
        self.cv_bridge = CvBridge()

        self.subscription = self.create_subscription(Image, '/camera/image_raw', self.image_callback, 10)
        self.publisher_1 = self.create_publisher(Pose2D, '/detected_aruco_1', 10)
        self.publisher_2 = self.create_publisher(Pose2D, '/detected_aruco_2', 10)
        self.publisher_3 = self.create_publisher(Pose2D, '/detected_aruco_3', 10)
        self.path_coordinates1 = []
        self.path_coordinates2 = []
        self.path_coordinates3 = []

    def image_callback(self, msg):
        #convert ROS image to opencv image
        try:
            cv_image = self.cv_bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        except Exception as e:
            self.get_logger().error('Error converting image: %s' % str(e))
            return

        # path_coordinates =[]
        width = 500
        height = 500
        cv_image = cv2.resize(cv_image, (width,height))
        arucoDict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50)
        arucoParams = cv2.aruco.DetectorParameters()
        arucoParams.adaptiveThreshWinSizeMin = 3
        arucoParams.adaptiveThreshWinSizeMax = 255
        arucoParams.adaptiveThreshWinSizeStep = 10
        (corners, ids, rejected) = cv2.aruco.detectMarkers(cv_image, arucoDict, parameters=arucoParams)
        
        if len(corners) > 0:
            # Flatten the ArUco IDs list
            ids = ids.flatten()
            print(ids)

            # Loop over the detected ArUCo corners
            a = np.count_nonzero(ids == 1)
            i = np.where(ids == 1)
            i = np.squeeze(i)

            b = np.count_nonzero(ids == 2)
            j = np.where(ids == 2)
            j = np.squeeze(j)

            c = np.count_nonzero(ids == 3)
            k = np.where(ids == 3)
            k = np.squeeze(k)
            corrners = corners
            for(Marker_corrners,id) in zip(corrners,ids):
                corrners=Marker_corrners.reshape((4,2))
                (topLeft,topRight,bottomRight,bottomLeft)= corrners

                # Convert each of the (x, y)-coordinate pairs to integers
                topRight = (int(topRight[0]), int(topRight[1]))
                bottomRight = (int(bottomRight[0]), int(bottomRight[1]))
                bottomLeft = (int(bottomLeft[0]), int(bottomLeft[1]))
                topLeft = (int(topLeft[0]), int(topLeft[1]))
            

                # Draw lines around the detected marker
                cv2.line(cv_image, topLeft, topRight, (0, 255, 0), 2)
                cv2.line(cv_image, topRight, bottomRight, (0, 255, 0), 2)
                cv2.line(cv_image, bottomRight, bottomLeft, (0, 255, 0), 2)
                cv2.line(cv_image, bottomLeft, topLeft, (0, 255, 0), 2)
                q=8.0
                cX = int((topLeft[0] + bottomRight[0]) / 2.0)
                cY = int((topLeft[1] + bottomRight[1]) / 2.0)
                
                theta = math.atan2(topRight[1] - topLeft[1], topRight[0] - topLeft[0])
                xp = float(math.sin(theta)*q + cX )
                yp = float(-math.cos(theta)*q + cY)

                cv2.putText(cv_image, str(id),(topLeft[0], topLeft[1] - 15), cv2.FONT_HERSHEY_SIMPLEX,0.5, (0, 255, 0), 2)
                if id == 1:
                    cv2.circle(cv_image, (int(xp), int(yp)), 4, (0, 255, 0), -1)                       
                    c_X1 = int((corners[i][0][0][0] + corners[i][0][2][0]) / 2.0)
                    c_Y1 = int((corners[i][0][0][1] + corners[i][0][2][1]) / 2.0)
                    self.path_coordinates1.append((c_X1,c_Y1))
                    # print(self.path_coordinates)
                    for w in range(1, len(self.path_coordinates1)):
                        cv2.line(cv_image, self.path_coordinates1[w - 1], self.path_coordinates1[w], (0, 0, 255), 2)

                    
                if id == 2:
                    cv2.circle(cv_image, (int(xp), int(yp)), 4, (0, 255, 0), -1)                       
                    c_X2 = int((corners[j][0][0][0] + corners[j][0][2][0]) / 2.0)
                    c_Y2 = int((corners[j][0][0][1] + corners[j][0][2][1]) / 2.0)
                    self.path_coordinates2.append((c_X2,c_Y2))
                    # print(self.path_coordinates)
                    for w1 in range(1, len(self.path_coordinates2)):
                        cv2.line(cv_image, self.path_coordinates2[w1 - 1], self.path_coordinates2[w1], (255, 0, 0), 2)

                if id == 3:
                    cv2.circle(cv_image, (int(xp), int(yp)), 4, (0, 255, 0), -1)                       
                    c_X3 = int((corners[k][0][0][0] + corners[k][0][2][0]) / 2.0)
                    c_Y3 = int((corners[k][0][0][1] + corners[k][0][2][1]) / 2.0)
                    self.path_coordinates3.append((c_X3,c_Y3))
                    # print(self.path_coordinates)
                    for w1 in range(1, len(self.path_coordinates3)):
                        cv2.line(cv_image, self.path_coordinates3[w1 - 1], self.path_coordinates3[w1], (255, 255, 255), 2)
                    
                # print("[INFO] ArUco marker ID: {}".format(ids))
                # # Show the output image
                cv2.imshow("Image", cv_image)
                cv2.waitKey(1)

            if a > 0:
                bot_markerCorners1 = corners[i]
                (topLeft1, topRight1, bottomRight1, bottomLeft1) = bot_markerCorners1[0]
                x1=float((topLeft1[0]+bottomRight1[0])/2)
                y1=float((topLeft1[1]+bottomRight1[1])/2)
                theta1 = math.atan2(topRight1[1] - topLeft1[1], topRight1[0] - topLeft1[0])
                hb_x1= x1
                hb_y1= y1 

                hb_theta1= theta1
                aruco_msg1 = Pose2D()
                aruco_msg1.x = hb_x1
                aruco_msg1.y = hb_y1
                aruco_msg1.theta = hb_theta1
                self.publisher_1.publish(aruco_msg1)
                print(hb_x1,hb_y1,hb_theta1)

            if b > 0:
                bot_markerCorners2 = corners[j]
                (topLeft2, topRight2, bottomRight2, bottomLeft2) = bot_markerCorners2[0]
                x2=float((topLeft2[0]+bottomRight2[0])/2)
                y2=float((topLeft2[1]+bottomRight2[1])/2)
                theta2 = math.atan2(topRight2[1] - topLeft2[1], topRight2[0] - topLeft2[0])
                hb_x2= x2
                hb_y2= y2 
                hb_theta2= theta2
                aruco_msg2 = Pose2D()
                aruco_msg2.x = hb_x2
                aruco_msg2.y = hb_y2
                aruco_msg2.theta = hb_theta2
                self.publisher_2.publish(aruco_msg2)

            if c > 0:    
                bot_markerCorners3 = corners[k]
                (topLeft3, topRight3, bottomRight3, bottomLeft3) = bot_markerCorners3[0]
                x3=float((topLeft3[0]+bottomRight3[0])/2)
                y3=float((topLeft3[1]+bottomRight3[1])/2)
                theta3 = math.atan2(topRight3[1] - topLeft3[1], topRight3[0] - topLeft3[0])
                hb_x3= x3
                hb_y3= y3 
                hb_theta3= theta3
                aruco_msg3 = Pose2D()
                aruco_msg3.x = hb_x3
                aruco_msg3.y = hb_y3
                aruco_msg3.theta = hb_theta3
                self.publisher_3.publish(aruco_msg3)

def main(args=None):
    rclpy.init(args=args)

    aruco_detector = ArUcoDetector()

    rclpy.spin(aruco_detector)

    aruco_detector.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
