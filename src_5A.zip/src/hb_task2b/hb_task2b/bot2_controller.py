#! /usr/bin/env python3

################### IMPORT MODULES #######################

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Pose2D
from geometry_msgs.msg import Wrench
import numpy as np
import time
import math
# from tf_transformations import euler_from_quaternion
from my_robot_interfaces.msg import Goal             


class HBController(Node):
    def __init__(self):
        super().__init__('hb_controller')
        

        # Initialise the required variables
        self.bot_2_x = 0.0
        self.bot_2_y = 0.0
        self.bot_2_theta = 0.0
        self.x_2_goal = []
        self.y_2_goal = []
        self.theta_2_goal = []
        self.bot_id = []
        self.v_x = 0.0
        self.v_y = 0.0
        self.w_z = 0.0
        self.max_vel_limit = 5.0
        self.min_vel_limit = -5.0
        self.max_vel_limit_1 = 2.0
        self.min_vel_limit_1 = -2.0
        self.i = 0

        # Initialze Publisher and Subscriber
        # NOTE: You are strictly NOT-ALLOWED to use "cmd_vel" or "odom" topics in this task
	    #	Use the below given topics to generate motion for the robot.
	    #   /hb_bot_1/left_wheel_force,
	    #   /hb_bot_1/right_wheel_force,
	    #   /hb_bot_1/left_wheel_force

        self.subscription = self.create_subscription(
            Goal, 'hb_bot_2/goal', self.goalCallBack, 10)  
        self.pose_subscribe_2 = self.create_subscription(Pose2D,'/detected_aruco_2', self.poseCallback_1, 10 )
        self.vel_publisher_1 = self.create_publisher(Wrench,'/hb_bot_2/left_wheel_force', 10)
        self.vel_publisher_2 = self.create_publisher(Wrench,'/hb_bot_2/rear_wheel_force', 10)
        self.vel_publisher_3 = self.create_publisher(Wrench,'/hb_bot_2/right_wheel_force', 10)
        self.subscription  # Prevent unused variable warning

        # For maintaining control loop rate.

        self.rate = self.create_rate(100)
        self.kp = 3.0
        # self.ki= 1.0
        # self.kd= 0.0


    def inverse_kinematics(self):
        ############ ADD YOUR CODE HERE ############

        a1 = math.pi * (5/6)
        a2 = math.pi * (3/2)
        a3 = math.pi * (1/6)
        R = 0.68
        a = 0.14
        arr2 = np.array([self.v_x,self.v_y,self.w_z])
        
        arr2 = arr2.reshape(3,1)
        arr3 = np.array([[-math.sin(a1)/a,math.cos(a1)/a,R/a],[-math.sin(a2)/a,math.cos(a2)/a,R/a],[-math.sin(a3)/a,math.cos(a3)/a,R/a] ])

        arr1 = arr3@arr2
        arr1 = arr1.reshape(1,3)
        return arr1

        # INSTRUCTIONS & HELP : 
        #	-> Use the target velocity you calculated for the robot in previous task, and
        #	Process it further to find what proportions of that effort should be given to 3 individuals wheels !!
        #	Publish the calculated efforts to actuate robot by applying force vectors on provided topics
        ############################################

    def goalCallBack(self, msg):
        self.bot_id.append(msg.bot_id)
        self.x_2_goal.append(msg.x) 
        self.y_2_goal.append(msg.y)
        self.theta_2_goal.append(msg.theta)
    
    def poseCallback_1(self, pose_2):
        self.bot_2_x = pose_2.x
        self.bot_2_y = pose_2.y
        self.bot_2_theta = pose_2.theta


def main(args=None):
    rclpy.init(args=args)
    
    hb_controller = HBController()
       
    # Main loop
    while rclpy.ok():
        l1 = len(hb_controller.x_2_goal)
        print("length",l1)
        if l1>0:
            x_goal  = hb_controller.x_2_goal[0]
            y_goal  = hb_controller.y_2_goal[0]
            theta_goal  = hb_controller.theta_2_goal[0]
            print(theta_goal)
            l = len(x_goal)

            i = hb_controller.i

            if i>0:
                hb_controller.max_vel_limit = hb_controller.max_vel_limit_1
                hb_controller.min_vel_limit = hb_controller.min_vel_limit_1

            # Calculate Error from feedback
            if i < l:    
                e_x = x_goal[i] - hb_controller.bot_2_x
                e_y = y_goal[i] - hb_controller.bot_2_y
                e_theta = -theta_goal + hb_controller.bot_2_theta
                print("goal point:",x_goal[i], y_goal[i],theta_goal)
                print("error:", e_x, e_y,e_theta)
                # print(e_x,e_y,e_theta)

                e_x_robot =  math.cos(hb_controller.bot_2_theta)*e_x + math.sin(hb_controller.bot_2_theta)*e_y
                e_y_robot =  math.sin(hb_controller.bot_2_theta)*e_x - math.cos(hb_controller.bot_2_theta)*e_y

                hb_controller.v_x = (hb_controller.kp)*(e_x_robot)
                hb_controller.v_y = (hb_controller.kp)*(e_y_robot)
                hb_controller.w_z = (hb_controller.kp)*(e_theta)
                # hb_controller.v_x = (hb_controller.ki)*(e_x_robot)
                # hb_controller.v_y = (hb_controller.ki)*(e_y_robot)
                # hb_controller.w_z = (hb_controller.ki)*(e_theta)
                # hb_controller.v_x = (hb_controller.kd)*(e_x_robot)
                # hb_controller.v_y = (hb_controller.kd)*(e_y_robot)
                # hb_controller.w_z = (hb_controller.kd)*(e_theta)

                if hb_controller.v_x > hb_controller.max_vel_limit:
                    hb_controller.v_x = hb_controller.max_vel_limit
                
                if hb_controller.v_x < hb_controller.min_vel_limit:
                    hb_controller.v_x = hb_controller.min_vel_limit

                if hb_controller.v_y > hb_controller.max_vel_limit:
                    hb_controller.v_y = hb_controller.max_vel_limit

                if hb_controller.v_y < hb_controller.min_vel_limit:
                    hb_controller.v_y = hb_controller.min_vel_limit

                if i == 0:
                                
                    if math.sqrt((e_x_robot)**2 + (e_y_robot)**2) < 50.0:
                        if hb_controller.v_x > hb_controller.max_vel_limit_1:
                            hb_controller.v_x = hb_controller.max_vel_limit_1
                        
                        if hb_controller.v_x < hb_controller.min_vel_limit_1:
                            hb_controller.v_x = hb_controller.min_vel_limit_1

                        if hb_controller.v_y > hb_controller.max_vel_limit_1:
                            hb_controller.v_y = hb_controller.max_vel_limit_1


                        if hb_controller.v_y < hb_controller.min_vel_limit_1:
                            hb_controller.v_y = hb_controller.min_vel_limit_1

                # [v1,v2,v3] = T*[v_x,v_y,w_z]
                arr = hb_controller.inverse_kinematics()
                
                #hb_controller.get_logger().info('The inverse kinematics array is: %s', arr) 
                [v1,v2,v3] = arr[0]

                A = Wrench()
                B = Wrench()
                C = Wrench()
                A.force.y = v1
                B.force.y = v2
                C.force.y = v3

                hb_controller.vel_publisher_1.publish(A)
                hb_controller.vel_publisher_2.publish(B)
                hb_controller.vel_publisher_3.publish(C)
                
                if math.sqrt((e_x_robot)**2 + (e_y_robot)**2) < 1.0:
                    A.force.y = 0.0
                    B.force.y = 0.0
                    C.force.y = 0.0   
                    hb_controller.i = hb_controller.i + 1  
                    print(hb_controller.i)
                else:
                    hb_controller.i = hb_controller.i  
                    print(hb_controller.i) 
                
                if hb_controller.i ==l:
                    hb_controller.i=0   
        # Spin once to process callbacks
        rclpy.spin_once(hb_controller)
    
    # Destroy the node and shut down ROS
    hb_controller.destroy_node()
    rclpy.shutdown()

# Entry point of the script
if __name__ == '__main__':
    main()