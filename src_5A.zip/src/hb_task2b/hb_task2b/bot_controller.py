################### IMPORT MODULES #######################

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Wrench, Pose2D
from nav_msgs.msg import Odometry
import time
import math
from tf_transformations import euler_from_quaternion
from my_robot_interfaces.srv import NextGoal     
import numpy as np        

##############################################################

# Initialize Global variables
pose_x = [0.0, 0.0, 0.0]
pose_y = [0.0, 0.0, 0.0]
pose_theta = [0.0, 0.0, 0.0]

# Collision avoidance parameters
collision_threshold = 50.0  # Distance threshold for collision avoidance
repulsive_gain = 10000.0  # Increased gain for repulsive force

# Arena boundaries
top_left = [20, 20]
top_right = [480, 20]
bottom_left = [20, 480]
bottom_right = [480, 480]

x_min, x_max = top_left[0], top_right[0]
y_min, y_max = top_left[1], bottom_left[1]

# Define the HBController class, which is a ROS node
class HBController(Node):
    def __init__(self, bot_id):
        super().__init__(f'hb_controller_{bot_id}')
        self.bot_id = bot_id
        self.get_logger().info(f'Controller for bot {bot_id} has been started.')
        
        # Initialize Publisher and Subscriber
        self.det_ar_sub = self.create_subscription(Pose2D, f'/detected_aruco_{bot_id}', self.get_pose_callback, 10)

        self.left_force_pub = self.create_publisher(Wrench, f'/hb_bot_{bot_id}/left_wheel_force', 10)
        self.right_force_pub = self.create_publisher(Wrench, f'/hb_bot_{bot_id}/right_wheel_force', 10)
        self.rear_force_pub = self.create_publisher(Wrench, f'/hb_bot_{bot_id}/rear_wheel_force', 10)
        
        # For maintaining control loop rate.
        self.rate = self.create_rate(100)
        self.vel_lim = 100
        self.Kp_lin_x = 10
        self.Kp_lin_y = 10
        self.Kp_ang = 200.0
        
        # client for the "next_goal" service
        self.cli = self.create_client(NextGoal, f'next_goal_{bot_id}')      
        self.req = NextGoal.Request() 
        self.index = 0

    def send_request(self, request_goal):
        self.req.request_goal = request_goal
        self.future = self.cli.call_async(self.req)

    def inverse_kinematics(self, vx, vy, vtheta):
        matrix = np.array([[-1.0, -1.732/3, 0.68],[-1.0, 1.732/3, 0.68],[2.0, 0.0, 0.68]])
        return tuple(matrix @ np.array([[vx],[vy],[vtheta]]).flatten())
    
    def rotation_matrix(self, vx, vy):
        matrix = np.array([[ np.cos(pose_theta[self.bot_id-1]), np.sin(pose_theta[self.bot_id-1])],
                           [-np.sin(pose_theta[self.bot_id-1]), np.cos(pose_theta[self.bot_id-1])]])
        return tuple(matrix @ np.array([[vx], [vy]]).flatten())

    def get_pose_callback(self, msg: Pose2D):
        global pose_x, pose_y, pose_theta
        pose_x[self.bot_id-1] = max(x_min, min(msg.x - 250, x_max))
        pose_y[self.bot_id-1] = max(y_min, min(250 - msg.y, y_max))
        pose_theta[self.bot_id-1] = msg.theta


def main(args=None):
    rclpy.init(args=args)
    time.sleep(1)
    
    hb_controllers = [HBController(i+1) for i in range(3)]
    
    for hb in hb_controllers:
        hb.send_request(hb.index)
    
    x_goal, y_goal, theta_goal = [0.0]*3, [0.0]*3, [0.0]*3

    while rclpy.ok():
        for i, hb in enumerate(hb_controllers):
            if hb.future.done():
                try:
                    response = hb.future.result()
                except Exception as e:
                    hb.get_logger().info(f'Service call failed {e}')
                else:
                    x_goal[i], y_goal[i], theta_goal[i] = response.x_goal, response.y_goal, response.theta_goal
                    hb.index = 0 if response.end_of_list else hb.index + 1
                    hb.send_request(hb.index)

            error_x, error_y = x_goal[i] - pose_x[i], y_goal[i] - pose_y[i]
            error_x, error_y = hb.rotation_matrix(error_x, error_y)

            # Collision avoidance
            rep_x, rep_y = 0.0, 0.0
            for j in range(3):
                if i != j:
                    dist = math.sqrt((pose_x[i] - pose_x[j])**2 + (pose_y[i] - pose_y[j])**2)
                    safe_dist = max(dist, 1e-2)  # Prevents division by very small numbers
                    if dist < collision_threshold:
                        rep_x += repulsive_gain * (pose_x[i] - pose_x[j]) / (safe_dist**3)
                        rep_y += repulsive_gain * (pose_y[i] - pose_y[j]) / (safe_dist**3)

            error_x += rep_x
            error_y += rep_y

            # Keep robots within the arena boundaries
            pose_x[i] = max(x_min, min(pose_x[i], x_max))
            pose_y[i] = max(y_min, min(pose_y[i], y_max))

            vel_x = max(min(hb.Kp_lin_x * error_x, hb.vel_lim), -hb.vel_lim)
            vel_y = max(min(hb.Kp_lin_y * error_y, hb.vel_lim), -hb.vel_lim)
            vel_theta = max(min(hb.Kp_ang * (theta_goal[i] - pose_theta[i]), hb.vel_lim), -hb.vel_lim)

            vl, vr, vb = hb.inverse_kinematics(vel_x, vel_y, vel_theta)
            
            fl, fr, fb = Wrench(), Wrench(), Wrench()
            fl.force.x, fr.force.x, fb.force.x = vl, vr, vb
            
            hb.left_force_pub.publish(fl)
            hb.right_force_pub.publish(fr)
            hb.rear_force_pub.publish(fb)

        for hb in hb_controllers:
            rclpy.spin_once(hb, timeout_sec=0.01)
    
    for hb in hb_controllers:
        hb.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
