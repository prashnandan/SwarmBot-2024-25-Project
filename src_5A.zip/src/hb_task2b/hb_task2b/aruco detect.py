import cv2
import numpy as np
# import cv2.aruco as aruco

# Load ArUco dictionary and parameters
aruco_dict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50)
aruco_params = cv2.aruco.DetectorParameters()

# Camera calibration parameters (Replace with your actual calibration results)
camera_matrix = np.array([[800, 0, 320], [0, 800, 240], [0, 0, 1]])  # Example values
dist_coeffs = np.array([0, 0, 0, 0, 0])  # Assuming no distortion

# Marker real-world size in meters (adjust based on your actual marker size)
marker_length = 0.05  # 5 cm

# Open webcam
cap = cv2.VideoCapture(2)

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    # Convert to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Detect markers
    corners, ids, _ = cv2.aruco.detectMarkers(gray, aruco_dict, parameters=aruco_params)

    if ids is not None:
        # Draw detected markers
        cv2.aruco.drawDetectedMarkers(frame, corners, ids)

        # Estimate pose for each detected marker
        rvecs, tvecs, _ = cv2.aruco.estimatePoseSingleMarkers(corners, marker_length, camera_matrix, dist_coeffs)

        for i in range(len(ids)):
            # Draw axis on marker
           cv2.aruco.drawDetectedMarkers(frame, corners, ids)


            # Display translation (x, y, z) coordinates
        tvec_str = f"ID {ids[i][0]}: X={tvecs[i][0][0]:.2f}m, Y={tvecs[i][0][1]:.2f}m, Z={tvecs[i][0][2]:.2f}m"
        cv2.putText(frame, tvec_str, (10, 50 + i * 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

    # Show frame
    cv2.imshow("ArUco Marker Detection", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()

